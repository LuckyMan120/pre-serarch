module.exports = {
  transpileDependencies: ['vuetify'],
  runtimeCompiler: true,
}
